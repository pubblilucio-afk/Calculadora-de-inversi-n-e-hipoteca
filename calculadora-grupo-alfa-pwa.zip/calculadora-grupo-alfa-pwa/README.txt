CALCULADORA GRUPO ALFA - APP MÓVIL INSTALABLE

Qué contiene:
- index.html: la calculadora completa.
- manifest.webmanifest: configuración para instalarla como app.
- sw.js: archivo para que funcione como PWA.
- icon-192.png e icon-512.png: iconos de la app.

Cómo usarla:
1. Sube todos los archivos a Netlify, Vercel o cualquier hosting.
2. Abre el enlace desde el móvil.
3. En Android: menú del navegador > Instalar app / Añadir a pantalla de inicio.
4. En iPhone: Safari > compartir > Añadir a pantalla de inicio.

Importante:
Para instalarla como app real, debe estar publicada en una URL HTTPS.
Abierta como archivo local funcionará la calculadora, pero no la instalación completa PWA.
